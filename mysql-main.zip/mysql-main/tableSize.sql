SELECT table_name, 
       engine AS DBエンジン, 
       table_rows AS 行数,
       avg_row_length AS 平均レコード長,
       floor((data_length+index_length) / 1024 / 1024) AS ALL_MB,
       floor(data_length / 1024 / 1024) AS DATA_MB,
       floor(index_length / 1024 / 1024) AS INDEX_MB
FROM information_schema.tables
WHERE table_schema = database()
ORDER BY (data_length + index_length) DESC;
