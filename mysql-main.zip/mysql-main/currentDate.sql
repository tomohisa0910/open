select
 DATE_FORMAT(CURDATE(), '%Y%m%d') HOGE
FROM
 DUMMY

