SELECT table_schema, 
       floor(SUM(data_length + index_length) / 1024 / 1024) AS ALL_MB,
       floor(SUM((data_length) / 1024 / 1024)) AS DATA_MB,
       floor(SUM((index_length) / 1024 / 1024)) AS INDEX_MB
FROM information_schema.tables
GROUP BY table_schema
ORDER BY sum(data_length + index_length) DESC;
