--*DataTitle 'ログインテーブル'
SELECT
    ID,                                      -- ID
    USER_NAME,                               -- ユーザー名
    PASSWORD,                                -- パスワード
    SITE,                                    -- サイト名
    URL,                                     -- ログイン URL
    MEMO,                                    -- メモ
    SAFETY,                                  -- 安全
    FAVORITE,                                -- お気に入り
    CREATE_DATE,                             -- 登録日
    UPDATE_DATE                              -- 更新日
INTO OUTFILE '/var/lib/mysql-files/loginInfo.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    LOGIN_INFO
ORDER BY
    ID
