#!/bin/sh
# 全データベースのバックアップ
mysqldump --all-databases > all-databases.sql
