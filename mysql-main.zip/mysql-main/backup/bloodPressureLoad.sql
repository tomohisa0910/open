LOAD DATA INFILE "./backup/develop/bloodPressure.txt"
INTO TABLE BLOOD_PRESSURE
    FIELDS TERMINATED BY ','
    ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
IGNORE 1 ROWS
    (@1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14, @15, @16)
SET
    ID = @1,                                 -- ID
    RECORD_DATE = @2,                        -- 測定日
    TIME_AM = @3,                            -- 朝時刻
    MAX_AM = @4,                             -- 朝最高
    MIN_AM = @5,                             -- 朝最低
    PULSE_AM = @6,                           -- 朝脈拍
    TIME_PM = @7,                            -- 夜時刻
    MAX_PM = @8,                             -- 夜最高
    MIN_PM = @9,                             -- 夜最低
    PULSE_PM = @10,                          -- 夜脈拍
    MEDICINE = @11,                          -- 薬
    MOVEMENT = @12,                          -- 運動
    DRINKING = @13,                          -- 飲酒
    DIARY = @14                              -- 日記
;
