LOAD DATA INFILE "./backup/develop/loginInfo.txt"
INTO TABLE LOGIN_INFO
    FIELDS TERMINATED BY ','
    ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
IGNORE 1 ROWS
    (@1, @2, @3, @4, @5, @6, @7, @8, @9, @10)
SET
    ID = @1,                                 -- ID
    USER_NAME = @2,                          -- ユーザー名
    PASSWORD = @3,                           -- パスワード
    SITE = @4,                               -- サイト名
    URL = @5,                                -- ログイン URL
    MEMO = @6,                               -- メモ
    SAFETY = @7,                             -- 安全
    FAVORITE = @8,                           -- お気に入り
    CREATE_DATE = @9,                        -- 登録日
    UPDATE_DATE = @10                        -- 更新日
;
