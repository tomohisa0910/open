LOAD DATA LOCAL INFILE "./backup/develop/bodyManage.txt" 
INTO TABLE BODY_MANAGE
    FIELDS TERMINATED BY ','
    LINES TERMINATED BY '\n' 
IGNORE 1 ROWS
(@1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14, @15, @16, @17, @18, @19, @20, @21, @22, @23)
SET
    RECORD_DATE = @1,
    RECORD_TIME = @2,
    AGE = @3,
    HEIGHT = @4,
    WEIGHT = @5,
    BMI = @6,
    FAT_PERCENTAGE = @7,
    MUSCLE_MASS = @13, 
    BONE_MASS = @19, 
    VISCERAL_FAT_LEVEL = @20,
    BASAL_METABOLIC_RATE = @21,
    BODY_AGE = @22,
    BODY_WATER_CONTENT = @23
;
