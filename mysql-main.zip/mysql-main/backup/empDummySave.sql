--*DataTitle 'EMP_DUMMYテーブル'
SELECT
    EMPNO,
    ENAME,
    JOB,
    MGR,
    HIREDATE,
    SAL,
    COMM,
    DEPTNO
INTO OUTFILE '/var/lib/mysql-files/empDummy.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    EMP_DUMMY
ORDER BY
    EMPNO
;
