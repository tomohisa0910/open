#!/bin/sh
# develop データベースのバックアップ
mysqldump develop  > develop.sql
