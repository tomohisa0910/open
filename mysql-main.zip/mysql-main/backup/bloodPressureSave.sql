--*DataTitle '血圧テーブル'
SELECT
    ID,                                      -- ID
    RECORD_DATE,                             -- 測定日
    TIME_AM,                                 -- 朝時刻
    MAX_AM,                                  -- 朝最高
    MIN_AM,                                  -- 朝最低
    PULSE_AM,                                -- 朝脈拍
    TIME_PM,                                 -- 夜時刻
    MAX_PM,                                  -- 夜最高
    MIN_PM,                                  -- 夜最低
    PULSE_PM,                                -- 夜脈拍
    MEDICINE,                                -- 薬
    MOVEMENT,                                -- 運動
    DRINKING,                                -- 飲酒
    DIARY,                                   -- 日記
    CREATE_DATE,                             -- 登録日
    UPDATE_DATE                              -- 更新日
INTO OUTFILE '/var/lib/mysql-files/bloodPressure.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    BLOOD_PRESSURE
ORDER BY
    ID
