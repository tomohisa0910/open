-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: develop
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0+deb9u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ACCOUNT`
--

DROP TABLE IF EXISTS `ACCOUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ACCOUNT` (
  `CD` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'アカウントコード',
  `NAME` varchar(500) NOT NULL COMMENT 'アカウント名',
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日',
  `UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アカウントマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACCOUNT`
--

LOCK TABLES `ACCOUNT` WRITE;
/*!40000 ALTER TABLE `ACCOUNT` DISABLE KEYS */;
/*!40000 ALTER TABLE `ACCOUNT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ACTUAL`
--

DROP TABLE IF EXISTS `ACTUAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ACTUAL` (
  `ACTUAL_CD` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'データコード',
  `TRANSACTION_DATE` date NOT NULL COMMENT '日付',
  `CATEGORY_CD` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'カテゴリーコード',
  `ACCOUNT_CD` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'アカウントコード',
  `AMOUNT` decimal(15,0) NOT NULL DEFAULT '0' COMMENT '入出金額',
  `MEMO_CD` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'メモコード',
  `GROUP_CD` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'グループコード',
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日',
  `UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`ACTUAL_CD`),
  KEY `FK_CATEGORY_CD` (`CATEGORY_CD`),
  KEY `FK_ACCOUNT_CD` (`ACCOUNT_CD`),
  KEY `FK_MEMO_CD` (`MEMO_CD`),
  KEY `FK_GROUPS_CD` (`GROUP_CD`),
  CONSTRAINT `FK_ACCOUNT_CD` FOREIGN KEY (`ACCOUNT_CD`) REFERENCES `ACCOUNT` (`CD`),
  CONSTRAINT `FK_CATEGORY_CD` FOREIGN KEY (`CATEGORY_CD`) REFERENCES `CATEGORY` (`CATEGORY_CD`),
  CONSTRAINT `FK_GROUPS_CD` FOREIGN KEY (`GROUP_CD`) REFERENCES `GROUPS` (`CD`),
  CONSTRAINT `FK_MEMO_CD` FOREIGN KEY (`MEMO_CD`) REFERENCES `MEMO` (`CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='家計簿テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ACTUAL`
--

LOCK TABLES `ACTUAL` WRITE;
/*!40000 ALTER TABLE `ACTUAL` DISABLE KEYS */;
/*!40000 ALTER TABLE `ACTUAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BONUS`
--

DROP TABLE IF EXISTS `BONUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BONUS` (
  `ENAME` varchar(10) DEFAULT NULL,
  `JOB` varchar(9) DEFAULT NULL,
  `SAL` decimal(10,0) DEFAULT NULL,
  `COMM` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BONUS`
--

LOCK TABLES `BONUS` WRITE;
/*!40000 ALTER TABLE `BONUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `BONUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CATEGORY`
--

DROP TABLE IF EXISTS `CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CATEGORY` (
  `CATEGORY_CD` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'カテゴリーコード',
  `CATEGORY_NAME` varchar(500) NOT NULL COMMENT 'カテゴリー名称',
  `PARENT_CATEGORY_CD` smallint(6) DEFAULT NULL COMMENT '親カテゴリーコード',
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日',
  `UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`CATEGORY_CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='カテゴリーマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CATEGORY`
--

LOCK TABLES `CATEGORY` WRITE;
/*!40000 ALTER TABLE `CATEGORY` DISABLE KEYS */;
/*!40000 ALTER TABLE `CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEPT`
--

DROP TABLE IF EXISTS `DEPT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEPT` (
  `DEPTNO` decimal(2,0) DEFAULT NULL,
  `DNAME` varchar(14) DEFAULT NULL,
  `LOC` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEPT`
--

LOCK TABLES `DEPT` WRITE;
/*!40000 ALTER TABLE `DEPT` DISABLE KEYS */;
INSERT INTO `DEPT` VALUES (10,'ACCOUNTING','NEW YORK'),(20,'RESEARCH','DALLAS'),(30,'SALES','CHICAGO'),(40,'OPERATIONS','BOSTON');
/*!40000 ALTER TABLE `DEPT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DUMMY`
--

DROP TABLE IF EXISTS `DUMMY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DUMMY` (
  `DUMMY` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DUMMY`
--

LOCK TABLES `DUMMY` WRITE;
/*!40000 ALTER TABLE `DUMMY` DISABLE KEYS */;
INSERT INTO `DUMMY` VALUES (0);
/*!40000 ALTER TABLE `DUMMY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMP`
--

DROP TABLE IF EXISTS `EMP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EMP` (
  `EMPNO` decimal(4,0) NOT NULL,
  `ENAME` varchar(10) DEFAULT NULL,
  `JOB` varchar(9) DEFAULT NULL,
  `MGR` decimal(4,0) DEFAULT NULL,
  `HIREDATE` date DEFAULT NULL,
  `SAL` decimal(7,2) DEFAULT NULL,
  `COMM` decimal(7,2) DEFAULT NULL,
  `DEPTNO` decimal(2,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMP`
--

LOCK TABLES `EMP` WRITE;
/*!40000 ALTER TABLE `EMP` DISABLE KEYS */;
INSERT INTO `EMP` VALUES (7369,'SMITH','CLERK',7902,'2022-03-04',800.00,NULL,20),(7499,'ALLEN','SALESMAN',7698,'2022-03-04',1600.00,300.00,30),(7521,'WARD','SALESMAN',7698,'2022-03-04',1250.00,500.00,30),(7566,'JONES','MANAGER',7839,'2022-03-04',2975.00,NULL,20),(7654,'MARTIN','SALESMAN',7698,'2022-03-04',1250.00,1400.00,30),(7698,'BLAKE','MANAGER',7839,'2022-03-04',2850.00,NULL,30),(7782,'CLARK','MANAGER',7839,'2022-03-04',2450.00,NULL,10),(7788,'SCOTT','ANALYST',7566,'2022-03-04',3000.00,NULL,20),(7839,'KING','PRESIDENT',NULL,'2022-03-04',5000.00,NULL,10),(7844,'TURNER','SALESMAN',7698,'2022-03-04',1500.00,0.00,30),(7876,'ADAMS','CLERK',7788,'2022-03-04',1100.00,NULL,20),(7900,'JAMES','CLERK',7698,'2022-03-04',950.00,NULL,30),(7902,'FORD','ANALYST',7566,'2022-03-04',3000.00,NULL,20),(7934,'MILLER','CLERK',7782,'2022-03-04',1300.00,NULL,10);
/*!40000 ALTER TABLE `EMP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GROUPS`
--

DROP TABLE IF EXISTS `GROUPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GROUPS` (
  `CD` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'グループコード',
  `NAME` varchar(500) NOT NULL COMMENT 'グループ名',
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日',
  `UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グループマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GROUPS`
--

LOCK TABLES `GROUPS` WRITE;
/*!40000 ALTER TABLE `GROUPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `GROUPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MEMO`
--

DROP TABLE IF EXISTS `MEMO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MEMO` (
  `CD` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'メモコード',
  `CONTENT` varchar(500) NOT NULL COMMENT 'メモ内容',
  `CREATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登録日',
  `UPDATE_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`CD`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メモマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MEMO`
--

LOCK TABLES `MEMO` WRITE;
/*!40000 ALTER TABLE `MEMO` DISABLE KEYS */;
/*!40000 ALTER TABLE `MEMO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALGRADE`
--

DROP TABLE IF EXISTS `SALGRADE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SALGRADE` (
  `GRADE` decimal(10,0) DEFAULT NULL,
  `LOSAL` decimal(10,0) DEFAULT NULL,
  `HISAL` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALGRADE`
--

LOCK TABLES `SALGRADE` WRITE;
/*!40000 ALTER TABLE `SALGRADE` DISABLE KEYS */;
INSERT INTO `SALGRADE` VALUES (1,700,1200),(2,1201,1400),(3,1401,2000),(4,2001,3000),(5,3001,9999);
/*!40000 ALTER TABLE `SALGRADE` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-27 12:46:15
