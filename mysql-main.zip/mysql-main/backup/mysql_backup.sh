#!/bin/bash

HOST="192.168.1.5"
PORT="13306"
USER="root"
PASSWORD="manager"
DATABASE_NAME="develop"

SRC_DIR=/var/lib/docker/volumes/tomo-mysql-files/_data
DST_DIR=/mnt/192_168_1_3_public/debian/backups/tomo-mysql/develop

# テーブル名の配列
TABLES=( \
    "ACCOUNT"  \
    "ACTUAL"  \
    "BLOOD_PRESSURE"  \
    "BODY_MANAGE"  \
    "CATEGORY"  \
    "CODENAME"  \
    "EMP_DUMMY"  \
    "LOGIN_INFO"  \
    "MGROUP"  \
)

for TABLE in "${TABLES[@]}"
do
    OUTPUT_FILE="/var/lib/mysql-files/${TABLE}.txt"
    
    # MySQLのSELECT INTO OUTFILE文を使用してテーブルのデータをCSV形式のTXTファイルに書き出す
    mysql --host=$HOST \
          --port=$PORT \
          --user=$USER \
          --password=$PASSWORD \
          $DATABASE_NAME -e "SELECT * FROM $TABLE INTO OUTFILE '$OUTPUT_FILE' FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n';"
    
    echo "Table $TABLE exported to $OUTPUT_FILE"
done

TARGET_DIR="$DST_DIR"/"$(date +%Y%m%d)"
sudo mkdir "$TARGET_DIR"
sudo find $SRC_DIR -name "*.txt" | xargs -I% sudo mv % $TARGET_DIR
