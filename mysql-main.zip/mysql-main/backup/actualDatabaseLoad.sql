--*DataTitle '区分マスタ'
--*CaptionFromComment
LOAD DATA LOCAL INFILE "./backup/develop/codename.txt" 
    INTO TABLE CODENAME
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n' 
    IGNORE 1 ROWS
(@1, @2, @3, @4, @5, @6, @7)
SET
    ID = @1,                              -- ID
    TABLE_NAME = @2,                      -- テーブル名
    COLUMN_NAME = @3,                     -- 列名
    CODE = @4,                            -- コード
    VAL = @5,                             -- 値
    CREATE_DATE = @6,                     -- 登録日
    UPDATE_DATE = @7                      -- 更新日
;

--*DataTitle 'グループマスタ'
--*CaptionFromComment
LOAD DATA LOCAL INFILE "./backup/develop/groups.txt" 
    INTO TABLE GROUPS
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n' 
    IGNORE 1 ROWS
(@1, @2, @3, @4)
SET
    CD = @1,                              -- グループコード
    NAME = @2,                            -- グループ名
    CREATE_DATE = @3,                     -- 登録日
    UPDATE_DATE = @4                      -- 更新日
;

--*DataTitle 'アカウントマスタ'
--*CaptionFromComment
LOAD DATA LOCAL INFILE "./backup/develop/account.txt" 
   INTO TABLE ACCOUNT
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n' 
    IGNORE 1 ROWS
(@1, @2, @3, @4, @5)
SET
    CD = @1,                              -- コード
    NAME = @2,                            -- 名称
    KIND_CD = @3,                         -- 種類コード
    CREATE_DATE = @4,                     -- 登録日
    UPDATE_DATE = @5                      -- 更新日
;

--*DataTitle 'カテゴリーマスタ'
--*CaptionFromComment
LOAD DATA LOCAL INFILE "./backup/develop/category.txt" 
    INTO TABLE CATEGORY
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n' 
    IGNORE 1 ROWS
(@1, @2, @3, @4, @5, @6, @7)
SET
    ID = @1,                              -- ID
    CATEGORY_CD = @2,                     -- カテゴリーコード
    CATEGORY_LEVEL = @3,                  -- 階層レベル
    PARENT_CATEGORY_CD = @4,              -- 親カテゴリーコード
    CATEGORY_NAME = @5,                   -- カテゴリー名称
    CREATE_DATE = @6,                     -- 登録日
    UPDATE_DATE = @7                      -- 更新日
;

--*DataTitle '入出金データ'
--*CaptionFromComment
LOAD DATA LOCAL INFILE "./backup/develop/actual.txt" 
    INTO TABLE ACTUAL
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n' 
    IGNORE 1 ROWS
(@1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13)
SET
    ACTUAL_CD = @1,                       -- データコード
    TRANSACTION_DATE = @2,                -- 日付
    CATEGORY = @3,                        -- カテゴリー
    ACCOUNT = @4,                         -- アカウント
    INCOME = @5,                          -- 入金額
    EXPENDITURE = @6,                     -- 出金額
    MEMO = @7,                            -- メモ
    GROUP_NM = @8,                        -- グループ
    CATEGORY_CD = @9,                     -- カテゴリーコード
    ACCOUNT_CD = @10,                     -- アカウントコード
    GROUP_CD = @11,                       -- グループコード
    CREATE_DATE = @12,                    -- 登録日
    UPDATE_DATE = @13                     -- 更新日
;
