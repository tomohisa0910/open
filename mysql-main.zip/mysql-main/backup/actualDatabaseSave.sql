--*DataTitle '入出金データ'
--*CaptionFromComment
SELECT
    ACTUAL_CD,                            -- データコード
    TRANSACTION_DATE,                     -- 日付
    CATEGORY,                             -- カテゴリー
    ACCOUNT,                              -- アカウント
    INCOME,                               -- 入金額
    EXPENDITURE,                          -- 出金額
    MEMO,                                 -- メモ
    GROUP_NM,                             -- グループ
    CATEGORY_CD,                          -- カテゴリーコード
    ACCOUNT_CD,                           -- アカウントコード
    GROUP_CD,                             -- グループコード
    CREATE_DATE,                          -- 登録日
    UPDATE_DATE                           -- 更新日
INTO OUTFILE '/var/lib/mysql-files/actual.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    ACTUAL
ORDER BY
    ACTUAL_CD
;
--*DataTitle 'カテゴリーマスタ'
--*CaptionFromComment
SELECT
    ID,                                      -- ID
    CATEGORY_CD,                             -- カテゴリーコード
    CATEGORY_LEVEL,                          -- 階層レベル
    PARENT_CATEGORY_CD,                      -- 親カテゴリーコード
    CATEGORY_NAME,                           -- カテゴリー名称
    CREATE_DATE,                             -- 登録日
    UPDATE_DATE                              -- 更新日
INTO OUTFILE '/var/lib/mysql-files/category.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    CATEGORY
ORDER BY
    CATEGORY_CD
;
--*DataTitle 'アカウントマスタ'
--*CaptionFromComment
SELECT
    CD,                                      -- コード
    NAME,                                    -- 名称
    KIND_CD,                                 -- 種類コード
    CREATE_DATE,                             -- 登録日
    UPDATE_DATE                              -- 更新日
INTO OUTFILE '/var/lib/mysql-files/account.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    ACCOUNT
ORDER BY
    CD
;
--*DataTitle 'グループマスタ'
--*CaptionFromComment
SELECT
    CD                                        -- グループコード
    , NAME                                    -- グループ名
    , CREATE_DATE                             -- 登録日
    , UPDATE_DATE                             -- 更新日
INTO OUTFILE '/var/lib/mysql-files/mgroup.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    MGROUP
ORDER BY
    CD
;
--*DataTitle '区分マスタ'
--*CaptionFromComment
SELECT
    ID                                        -- ID
    , TABLE_NAME                              -- テーブル名
    , COLUMN_NAME                             -- 列名
    , CODE                                    -- コード
    , VAL                                     -- 値
    , CREATE_DATE                             -- 登録日
    , UPDATE_DATE                             -- 更新日
INTO OUTFILE '/var/lib/mysql-files/codename.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    CODENAME 
ORDER BY
    ID
;
