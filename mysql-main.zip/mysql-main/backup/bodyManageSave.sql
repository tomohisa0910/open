--*DataTitle '体重テーブル'
--*CaptionFromComment
SELECT
    ID,                                       -- ID
    RECORD_DATE,                              -- 測定日
    RECORD_TIME,                              -- 時刻
    AGE,                                      -- 年齢
    HEIGHT,                                   -- 身長
    WEIGHT,                                   -- 体重
    BMI,                                      -- BMI
    FAT_PERCENTAGE,                           -- 全身体脂肪率
    MUSCLE_MASS,                              -- 全身筋肉量
    BONE_MASS,                                -- 推定骨量
    VISCERAL_FAT_LEVEL,                       -- 内臓脂肪レベル
    BASAL_METABOLIC_RATE,                     -- 基礎代謝量
    BODY_AGE,                                 -- 体内年齡
    BODY_WATER_CONTENT,                       -- 体水分率
    CREATE_DATE,                              -- 登録日
    UPDATE_DATE                              -- 更新日
INTO OUTFILE '/var/lib/mysql-files/bodyManage.txt'
    FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
    LINES TERMINATED BY '\n'
FROM
    BODY_MANAGE
ORDER BY
    ID
;
