#!/bin/sh
# operation データベースのバックアップ
mysqldump operation  > operation.sql
