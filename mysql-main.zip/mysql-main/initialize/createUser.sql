show databases;
###開発用
#データベースの作成
DROP DATABASE IF EXISTS develop;
CREATE DATABASE develop DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

#使用するデータベースの指定
USE develop;

#ユーザの作成と権限の付与
#システム管理者
DROP USER 'system'@'%';
CREATE USER 'system'@'%' IDENTIFIED BY 'manager';
GRANT ALL ON *.* TO system;

#開発用
DROP USER 'tomo'@'%';
CREATE USER 'tomo'@'%' IDENTIFIED BY 'ende9dnu9t';
GRANT ALL ON develop.* TO tomo;

#テスト用
DROP USER 'test'@'%';
CREATE USER 'test'@'%' IDENTIFIED BY 'test';
GRANT ALL ON develop.* TO test;


###運用
DROP DATABASE operation;
CREATE DATABASE operation DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE operation;
#システム管理者
DROP USER 'system'@'%';
CREATE USER 'system'@'%' IDENTIFIED BY 'manager';
GRANT ALL ON *.* TO system;

show databases;
