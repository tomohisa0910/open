#!/bin/bash
HOST=192.168.1.5
USER=admin
PASSWORD=manager

echo "build mysql script start."

#
mysql --host=$HOST --user=$USER --password=$PASSWORD < createUser.sql

