#!/bin/sh
# イメージ作成
# docker build -t tomo-ubuntu --build-arg BASE_NAME=ubuntu --build-arg VARIANT=latest .
# イメージ確認
# docker images
# イメージ起動
docker run --env-file run.env -it -d -p 8023:80 --link tomo-mysql:db --name tomo-phpmyadmin phpmyadmin
