#!/bin/sh
# イメージ作成
docker build -t tomo-portainer --build-arg BASE_NAME=portainer/portainer-ce --build-arg VARIANT=linux-amd64-2.19.4 .
# イメージ確認
docker images
# ボリューム作成
docker volume create tomo_portainer_data
# イメージ起動
docker run -d -p 19000:9000 -p19443:9443 --name tomo-portainer --restart=always -v tomo_portainer_data:/data tomo-portainer
