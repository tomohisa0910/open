#!/bin/sh
# イメージ作成
docker build -t tomo-postgres --build-arg BASE_NAME=postgres --build-arg VARIANT=latest .
# イメージ確認
docker images
# イメージ起動
docker run --env-file run.env -dp 15432:5432 --name tomo-postgres -v tomo-postgresql-data:/var/lib/postgresql/data tomo-postgres
