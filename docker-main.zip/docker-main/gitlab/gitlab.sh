#!/bin/sh
# 環境変数設定
export GITLAB_HOME=/var/gitlab
# イメージ起動
docker compose -p tomo-gitlab-ce up -d
