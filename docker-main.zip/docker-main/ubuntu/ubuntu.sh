#!/bin/sh
# イメージ作成
docker build -t tomo-ubuntu --build-arg BASE_NAME=ubuntu --build-arg VARIANT=latest .
# イメージ確認
docker images
# イメージ起動
docker run -it -d -p 8022:22 --name tomo-ubuntu -v tomo-ubuntu-data tomo-ubuntu
