#!/bin/sh
# イメージ作成
docker build -t tomo-mysql --build-arg BASE_NAME=mysql --build-arg VARIANT=8.2.0 .
# イメージ確認
docker images
# イメージ起動
docker run --env-file run.env -dp 13306:3306 --name tomo-mysql -v tomo-mysql-data:/var/lib/mysql -v tomo-mysql-files:/var/lib/mysql-files tomo-mysql
